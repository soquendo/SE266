<?php

//create array
//"=>" assigns key/value
$task =[
    'Student' => 'Sebastian Oquendo',
    'Title' => 'Mini-Task D: Associative Arrays',
    'Class' => 'SE266',
    'Date' => '10/10/2022'
];

require 'index.view.php';