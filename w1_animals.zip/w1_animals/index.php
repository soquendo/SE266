<?php

//create array
$animals = [
    'Chupacabra',
    'Bigfoot',
    'Nessie',
    'Yeti',
    'Minotaur'
];

//not sure how this works, will ask question in class
require 'index.view.php';

