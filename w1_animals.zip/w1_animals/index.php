<?php

$animals = [
    'Chupacabra',
    'Bigfoot',
    'Nessie',
    'Yeti',
    'Minotaur'
];

require 'index.view.php';
