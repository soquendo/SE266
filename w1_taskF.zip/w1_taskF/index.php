<?php

require 'functions.php';


$animals = ['dog', 'cat'];


dd('hello world');
//"die and dump"


require 'index.view.php';
