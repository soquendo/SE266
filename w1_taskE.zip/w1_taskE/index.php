<?php

//create array
//"=>" assigns key/value
$task =[
    'title' => 'Finish homework',
    'due' => 'Today',
    'assigned_to' => 'Sebastian',
    'completed' => true,
    'second_bool' => false
]; //title, due, assigned_to, completed

require 'index.view.php';